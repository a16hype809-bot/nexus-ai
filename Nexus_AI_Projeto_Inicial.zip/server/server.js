import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;

app.use(cors());
app.use(express.json({ limit: '12mb' }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Nexus AI API' }));

app.post('/api/chat', async (req, res) => {
  try {
    if (!apiKey) return res.status(500).json({ error: 'Configure OPENAI_API_KEY no backend.' });
    const { message, image, history = [] } = req.body || {};
    if ((!message || typeof message !== 'string') && !image) {
      return res.status(400).json({ error: 'Envie uma mensagem ou imagem.' });
    }
    const client = new OpenAI({ apiKey });
    const input = [];
    for (const item of history.slice(-12)) {
      if (!item || !['user', 'assistant'].includes(item.role) || typeof item.content !== 'string') continue;
      input.push({ role: item.role, content: item.content });
    }

    const content = [{ type: 'input_text', text: String(message || 'Analise a imagem enviada.') }];
    if (image?.data && typeof image.data === 'string') {
      const mime = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(image.mimeType)
        ? image.mimeType : 'image/jpeg';
      content.push({ type: 'input_image', image_url: `data:${mime};base64,${image.data}` });
    }
    input.push({ role: 'user', content });

    const result = await client.responses.create({
      model: 'gpt-4.1-mini',
      instructions: 'Você é Nexus AI, um assistente prestativo que responde em português do Brasil, de forma clara e segura.',
      input,
      max_output_tokens: 900
    });
    res.json({ reply: result.output_text || 'Não consegui produzir uma resposta agora.' });
  } catch (error) {
    console.error('Erro na chamada de IA:', error?.message || error);
    res.status(500).json({ error: 'O serviço de IA falhou. Verifique a configuração e tente novamente.' });
  }
});

app.listen(port, '0.0.0.0', () => {
  console.log(`Nexus AI API disponível na porta ${port}`);
});
