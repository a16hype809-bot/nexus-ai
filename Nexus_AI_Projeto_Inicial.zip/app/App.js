import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, Image, KeyboardAvoidingView,
  Platform, Pressable, SafeAreaView, Text, TextInput, View
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Speech from 'expo-speech';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';
import { StatusBar } from 'expo-status-bar';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://10.0.2.2:3000';
const C = {
  bg: '#101114', panel: '#191A20', panel2: '#24252D',
  border: '#343640', text: '#F4F4F7', muted: '#A5A6B3',
  accent: '#B8A6FF', user: '#30313B', danger: '#FF8A8A'
};

export default function App() {
  const [messages, setMessages] = useState([
    { id: 'welcome', role: 'assistant', text: 'Olá! Sou o Nexus AI. Como posso ajudar você hoje?' }
  ]);
  const [input, setInput] = useState('');
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);

  useSpeechRecognitionEvent('result', event => {
    const transcript = event.results?.[0]?.transcript;
    if (transcript) setInput(transcript);
  });
  useSpeechRecognitionEvent('end', () => setListening(false));
  useSpeechRecognitionEvent('error', event => {
    setListening(false);
    Alert.alert('Microfone', event.message || 'Não foi possível reconhecer a fala. Verifique as permissões e tente novamente.');
  });

  async function chooseImage() {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Permissão necessária', 'Permita o acesso às fotos para escolher uma imagem.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'], base64: true, quality: 0.75
      });
      if (!result.canceled && result.assets?.[0]) setImage(result.assets[0]);
    } catch (e) {
      Alert.alert('Imagem', 'Não foi possível abrir a galeria.');
    }
  }

  async function toggleVoice() {
    if (listening) {
      ExpoSpeechRecognitionModule.stop();
      setListening(false);
      return;
    }
    try {
      const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Permissão necessária', 'Permita o uso do microfone para falar com o Nexus AI.');
        return;
      }
      setListening(true);
      ExpoSpeechRecognitionModule.start({ lang: 'pt-BR', interimResults: true, continuous: false });
    } catch (e) {
      setListening(false);
      Alert.alert('Voz indisponível', 'O reconhecimento de fala pode exigir uma development build Android e um serviço de fala instalado.');
    }
  }

  async function send() {
    const text = input.trim();
    if ((!text && !image) || loading) return;
    const userMessage = {
      id: String(Date.now()), role: 'user',
      text: text || 'Analise esta imagem, por favor.',
      imageUri: image?.uri
    };
    const next = [...messages, userMessage];
    setMessages(next);
    setInput('');
    const selectedImage = image;
    setImage(null);
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text || 'Descreva e analise esta imagem.',
          image: selectedImage?.base64 ? {
            data: selectedImage.base64,
            mimeType: selectedImage.mimeType || 'image/jpeg'
          } : undefined,
          history: messages.filter(m => m.role === 'user' || m.role === 'assistant')
            .slice(-12).map(m => ({ role: m.role, content: m.text }))
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'O servidor não conseguiu responder.');
      setMessages(current => [...current, {
        id: String(Date.now() + 1), role: 'assistant',
        text: data.reply || 'Não recebi uma resposta.'
      }]);
    } catch (e) {
      setMessages(current => [...current, {
        id: String(Date.now() + 2), role: 'assistant',
        text: `Não consegui conectar ao serviço de IA. Verifique se o backend está funcionando e se EXPO_PUBLIC_API_URL está correto. Detalhe: ${e.message}`
      }]);
    } finally {
      setLoading(false);
    }
  }

  function speak(text) {
    Speech.stop();
    Speech.speak(text, { language: 'pt-BR', rate: 0.96 });
  }

  function renderMessage({ item }) {
    const isUser = item.role === 'user';
    return (
      <View style={{ alignSelf: isUser ? 'flex-end' : 'stretch', maxWidth: isUser ? '88%' : '100%', marginBottom: 18 }}>
        {item.imageUri ? <Image source={{ uri: item.imageUri }} style={{ width: 190, height: 150, borderRadius: 14, marginBottom: 8 }} /> : null}
        <View style={{
          backgroundColor: isUser ? C.user : 'transparent',
          borderRadius: 18, padding: isUser ? 13 : 2
        }}>
          <Text style={{ color: C.text, fontSize: 16, lineHeight: 24 }}>{item.text}</Text>
        </View>
        {!isUser && item.id !== 'welcome' ? (
          <Pressable onPress={() => speak(item.text)} style={{ alignSelf: 'flex-start', paddingVertical: 8, flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ color: C.accent, fontSize: 13 }}>🔊 Ouvir resposta</Text>
          </Pressable>
        ) : null}
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="light" />
      <View style={{ height: 64, paddingHorizontal: 18, borderBottomWidth: 1, borderBottomColor: C.border, flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: '#292638', alignItems: 'center', justifyContent: 'center', marginRight: 12 }}>
          <Text style={{ color: C.accent, fontSize: 23 }}>✦</Text>
        </View>
        <View>
          <Text style={{ color: C.text, fontSize: 18, fontWeight: '700' }}>Nexus AI</Text>
          <Text style={{ color: C.muted, fontSize: 12 }}>Seu assistente inteligente</Text>
        </View>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={10}>
        <FlatList
          data={messages}
          keyExtractor={item => item.id}
          renderItem={renderMessage}
          contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 22, paddingBottom: 12, flexGrow: 1 }}
          ListFooterComponent={loading ? <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingBottom: 14 }}><ActivityIndicator color={C.accent} /><Text style={{ color: C.muted }}>Nexus AI está pensando...</Text></View> : null}
        />

        {image ? (
          <View style={{ marginHorizontal: 14, marginBottom: 8, flexDirection: 'row', alignItems: 'center', backgroundColor: C.panel, padding: 8, borderRadius: 12 }}>
            <Image source={{ uri: image.uri }} style={{ width: 48, height: 48, borderRadius: 8 }} />
            <Text style={{ color: C.muted, flex: 1, marginLeft: 10 }}>Imagem pronta para análise</Text>
            <Pressable onPress={() => setImage(null)}><Text style={{ color: C.danger, padding: 8 }}>Remover</Text></Pressable>
          </View>
        ) : null}

        <View style={{ marginHorizontal: 12, marginBottom: 10, padding: 9, borderWidth: 1, borderColor: C.border, borderRadius: 20, backgroundColor: C.panel, flexDirection: 'row', alignItems: 'flex-end', gap: 7 }}>
          <Pressable onPress={chooseImage} accessibilityLabel="Escolher imagem" style={{ padding: 8 }}>
            <Text style={{ fontSize: 21, color: C.muted }}>＋</Text>
          </Pressable>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Pergunte alguma coisa..."
            placeholderTextColor="#858694"
            multiline
            maxLength={8000}
            style={{ color: C.text, flex: 1, maxHeight: 120, minHeight: 42, paddingTop: 10, paddingBottom: 8, fontSize: 16 }}
          />
          <Pressable onPress={toggleVoice} accessibilityLabel="Falar" style={{ padding: 8 }}>
            <Text style={{ fontSize: 20, color: listening ? C.danger : C.muted }}>{listening ? '■' : '🎙'}</Text>
          </Pressable>
          <Pressable onPress={send} disabled={loading || (!input.trim() && !image)} accessibilityLabel="Enviar mensagem"
            style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: (loading || (!input.trim() && !image)) ? '#5D586F' : C.accent, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#17151F', fontSize: 22, fontWeight: '700' }}>↑</Text>
          </Pressable>
        </View>
        <Text style={{ color: '#747583', fontSize: 10, textAlign: 'center', marginBottom: 7, paddingHorizontal: 18 }}>
          As respostas podem conter erros. Não envie informações pessoais ou confidenciais.
        </Text>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
