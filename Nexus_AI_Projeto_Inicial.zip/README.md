# Nexus AI — projeto inicial para Android

Este é um projeto inicial funcional de aplicativo Expo/React Native com:
- interface de chat escura;
- envio de mensagens para um backend;
- seleção de imagens para análise;
- entrada de voz por reconhecimento de fala;
- leitura de respostas em voz alta.

**Importante:** o app precisa de um backend com uma chave de API válida para gerar respostas reais. Não coloque a chave da API dentro do aplicativo Android. O backend deste projeto mantém a chave em uma variável de ambiente.

## Requisitos
- Um computador com Node.js LTS e npm.
- Uma conta de serviço de IA com API habilitada (o uso pode ter custo).
- Para criar builds na nuvem: uma conta Expo.
- Para publicar: conta Google Play Console e cumprir os requisitos atuais da Play Store.

## 1. Configurar o backend
Abra um terminal na pasta `server`:

```bash
npm install
```

Copie `.env.example` para `.env` e coloque sua chave de API em `OPENAI_API_KEY`.
Escolha uma chave de API do provedor e nunca compartilhe o arquivo `.env`.

Inicie o backend:
```bash
npm start
```

Para testar no celular, o backend deve estar acessível pela rede. Se estiver usando um computador e celular na mesma rede Wi-Fi, use o endereço IP local do computador em `EXPO_PUBLIC_API_URL`, por exemplo:
`http://192.168.1.20:3000`

Não exponha o backend publicamente sem autenticação, limites de uso e proteção contra abuso. Para produção, hospede-o em um serviço seguro HTTPS.

## 2. Configurar o aplicativo
Abra outro terminal na pasta `app`:

```bash
npm install
```

Crie um arquivo `.env` nesta pasta e configure:
```bash
EXPO_PUBLIC_API_URL=http://IP_DO_SEU_COMPUTADOR:3000
```

Inicie o projeto:
```bash
npx expo start
```

Para testar a interface rapidamente, use o Expo Go se as dependências suportarem o fluxo; reconhecimento de fala pode exigir uma development build. Para testar a função de microfone de forma confiável, crie uma development build Android.

## 3. Gerar APK de teste e AAB para Play Store
Instale e configure o EAS CLI:
```bash
npm install -g eas-cli
eas login
eas build:configure
```

APK para instalar e testar no celular:
```bash
eas build --platform android --profile preview
```

AAB para enviar à Play Store:
```bash
eas build --platform android --profile production
```

O perfil `preview` está configurado para gerar APK. O perfil `production` gera AAB.

## 4. Publicação
Antes de enviar:
- teste em dispositivos reais;
- adicione ícone, capturas de tela e descrição;
- publique uma política de privacidade acessível;
- explique o uso de microfone e imagens;
- preencha a seção de Segurança dos dados e classificação de conteúdo;
- cumpra os requisitos atuais de API-alvo, testes e conta de desenvolvedor do Google Play.

A Play Store pode exigir etapas adicionais para contas novas. A publicação não é automática e está sujeita à revisão do Google.

## Estrutura
- `app/`: aplicativo Android Expo/React Native.
- `server/`: API Node.js que chama o modelo de IA sem expor a chave no app.

## Limitações da primeira versão
- O histórico de conversas fica apenas na memória do app; não há conta nem sincronização.
- A análise de imagem envia a imagem selecionada para o backend e para o provedor de IA.
- A fala depende das permissões e dos serviços de reconhecimento de fala do dispositivo.
- O backend de exemplo não tem autenticação nem limites de uso para produção; adicione-os antes de hospedar publicamente.
